package com.techelevator;

import org.junit.*;

public class PurchasesTest {

//    @Test
//    public void main() {
//        // Arrange
//        Purchases sut = new Purchases();
//        // Act
//
//        // Assert
//    }
}
